# রাকিব (Rakib) - পার্সোনাল এআই অ্যান্ড্রয়েড অ্যাসিস্ট্যান্ট

গঠন: `backend/` (পাইথন সার্ভার) · `render.yaml` (Render কনফিগ) · `app/` (অ্যান্ড্রয়েড অ্যাপ) · `.github/workflows/build.yml` (APK বিল্ড)

## ধাপ ১: Gemini API Key
1. https://aistudio.google.com/apikey থেকে এক বা একাধিক কি নিন।
2. কমা দিয়ে লিখে রাখুন: `key1,key2,key3`

## ধাপ ২: GitHub-এ আপলোড
1. github.com-এ নতুন প্রাইভেট রিপোজিটরি (`rakib`) খুলুন।
2. এই ফোল্ডারের সব ফাইল (`.github` ফোল্ডারসহ) রিপোজিটরির রুটে আপলোড করুন।

## ধাপ ৩: Render-এ ব্যাকএন্ড
1. render.com -> New -> Blueprint (অথবা Web Service) -> আপনার রিপো বেছে নিন।
2. Blueprint হলে `render.yaml` নিজেই সব সেট করবে। Web Service হলে: Root Directory = `backend`, Build = `pip install -r requirements.txt`, Start = `python app.py`।
3. Environment Variables:
   - `GEMINI_API_KEYS` = `key1,key2,key3`
   - `APP_TOKEN` = নিজের বানানো লম্বা গোপন পাসওয়ার্ড
4. ডিপ্লয় শেষে URL (যেমন `https://rakib-backend.onrender.com`) টি ব্রাউজারে খুলে `{"status":"ok"}` দেখুন।
   (ফ্রি সার্ভার ১৫ মিনিট নিষ্ক্রিয় থাকলে ঘুমিয়ে যায়; প্রথম রিকোয়েস্টে ~৫০ সেকেন্ড লাগতে পারে।)

## ধাপ ৪: APK বিল্ড
1. রিপোর Actions ট্যাব -> "Build APK" -> Run workflow (বা push করলেই চলবে)।
2. শেষ হলে রান পেজের নিচে Artifacts থেকে `app-debug` ডাউনলোড করুন, জিপ খুলে `app-debug.apk` ইনস্টল করুন।

## ধাপ ৫: ফোনে সেটআপ
1. অ্যাপ খুলে Render URL ও `APP_TOKEN` দিন।
2. "অ্যাক্সেসিবিলিটি সার্ভিস চালু করুন" চেপে Installed apps -> রাকিব -> চালু করুন।
   Android 13+ এ বাটন ধূসর থাকলে: Settings -> Apps -> রাকিব -> ⋮ -> "Allow restricted settings", তারপর আবার চালু করুন।
3. বলুন/লিখুন: "হোয়াটসঅ্যাপ খুলে ...", "০১৭xxxxxxxx এ কল করো", "স্ক্রিনে কী লেখা আছে পড়ে শোনাও"।

## নিরাপত্তা নোট
- কল, "পাঠান/Send", পেমেন্ট, মুছে ফেলার আগে স্ক্রিনে হ্যাঁ/না নিশ্চিতকরণ আসে।
- পাসওয়ার্ড ফিল্ড স্ক্রিন-রিডিং থেকে বাদ যায়; তবু স্ক্রিনের লেখা Gemini-তে পাঠানো হয়, তাই ব্যাংকিং/OTP স্ক্রিনে ব্যবহার করবেন না।
- `APP_TOKEN` ছাড়া আপনার সার্ভার ব্যবহার করা যাবে না - এটি গোপন রাখুন।
