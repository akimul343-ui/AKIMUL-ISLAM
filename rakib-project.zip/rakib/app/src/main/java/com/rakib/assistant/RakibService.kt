package com.rakib.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit

class RakibService : AccessibilityService() {

    companion object {
        @Volatile var instance: RakibService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---- Screen reading (password fields are skipped) ----
    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "(স্ক্রিন পড়া যাচ্ছে না)"
        val sb = StringBuilder()
        walk(root, sb)
        return sb.toString().take(6000)
    }

    private fun walk(n: AccessibilityNodeInfo?, sb: StringBuilder) {
        if (n == null || sb.length > 6000) return
        if (!n.isPassword) {
            val t = n.text?.toString() ?: n.contentDescription?.toString()
            if (!t.isNullOrBlank()) {
                sb.append("- ").append(t.take(200))
                if (n.isClickable) sb.append(" [click]")
                if (n.isEditable) sb.append(" [input]")
                sb.append('\n')
            } else if (n.isEditable) {
                sb.append("- (খালি লেখার ঘর) [input]\n")
            }
        }
        for (i in 0 until n.childCount) walk(n.getChild(i), sb)
    }

    // ---- Actions ----
    fun perform(a: JSONObject): Boolean = when (a.optString("type")) {
        "click" -> clickText(a.optString("text"))
        "type" -> typeText(a.optString("text"))
        "open_app" -> openApp(a.optString("name"))
        "call" -> dial(a.optString("number"))
        "scroll" -> scrollScreen(a.optString("direction", "down"))
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        else -> true
    }

    private fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(text)) {
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable && !n.isPassword) return n
        for (i in 0 until n.childCount) findEditable(n.getChild(i))?.let { return it }
        return null
    }

    private fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) findScrollable(n.getChild(i))?.let { return it }
        return null
    }

    private fun scrollScreen(dir: String): Boolean {
        val s = findScrollable(rootInActiveWindow) ?: return false
        val act = if (dir == "up") AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                  else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        return s.performAction(act)
    }

    private fun openApp(name: String): Boolean {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(q, 0).firstOrNull {
            it.loadLabel(pm).toString().contains(name, ignoreCase = true)
        } ?: return false
        val i = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        return true
    }

    // Opens the dialer with the number filled in (safe default)
    private fun dial(number: String): Boolean {
        val num = number.filter { it.isDigit() || it == '+' }
        if (num.isEmpty()) return false
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    // ---- Confirmation overlay (visible over any app; no extra permission needed) ----
    fun confirm(msg: String): Boolean {
        val q = ArrayBlockingQueue<Boolean>(1)
        val holder = arrayOfNulls<View>(1)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val main = Handler(Looper.getMainLooper())
        main.post {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(48, 48, 48, 48)
                setBackgroundColor(Color.WHITE)
            }
            box.addView(TextView(this).apply { text = "রাকিব: $msg"; textSize = 18f; setTextColor(Color.BLACK) })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fun finish(v: Boolean) {
                try { wm.removeView(box) } catch (e: Exception) {}
                q.offer(v)
            }
            row.addView(Button(this).apply { text = "হ্যাঁ"; setOnClickListener { finish(true) } })
            row.addView(Button(this).apply { text = "না"; setOnClickListener { finish(false) } })
            box.addView(row)
            holder[0] = box
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
            lp.gravity = Gravity.CENTER
            wm.addView(box, lp)
        }
        val ans = q.poll(60, TimeUnit.SECONDS)
        if (ans == null) main.post { try { holder[0]?.let { wm.removeView(it) } } catch (e: Exception) {} }
        return ans ?: false
    }
}
