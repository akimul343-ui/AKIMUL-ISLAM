package com.rakib.assistant

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var urlBox: EditText
    private lateinit var tokenBox: EditText
    private var tts: TextToSpeech? = null
    private val history = JSONArray()
    private val prefs by lazy { getSharedPreferences("rakib", MODE_PRIVATE) }
    private val sensitive = listOf("send", "পাঠান", "পাঠাও", "pay", "পেমেন্ট", "delete", "মুছ", "confirm")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("bn", "BD") }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        root.addView(TextView(this).apply { text = "রাকিব - আপনার এআই সহকারী"; textSize = 22f })

        urlBox = EditText(this).apply {
            hint = "Render সার্ভার URL (https://...onrender.com)"
            setText(prefs.getString("url", ""))
            inputType = InputType.TYPE_TEXT_VARIATION_URI
        }
        tokenBox = EditText(this).apply {
            hint = "অ্যাপ টোকেন (APP_TOKEN)"
            setText(prefs.getString("token", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        root.addView(urlBox)
        root.addView(tokenBox)
        root.addView(Button(this).apply {
            text = "অ্যাক্সেসিবিলিটি সার্ভিস চালু করুন"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        logView = TextView(this).apply { textSize = 16f; setTextIsSelectable(true) }
        scroll = ScrollView(this).apply { addView(logView) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        input = EditText(this).apply { hint = "রাকিবকে বলুন বা লিখুন..." }
        root.addView(input)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Button(this).apply { text = "পাঠান"; setOnClickListener { submit() } }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply { text = "🎤 বলুন"; setOnClickListener { listen() } }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)
        setContentView(root)
        log("রাকিব: আসসালামু আলাইকুম! আমি রাকিব। কীভাবে সাহায্য করতে পারি?")
    }

    private fun listen() {
        try {
            startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD"), 1)
        } catch (e: Exception) { log("ভয়েস ইনপুট এই ফোনে পাওয়া যাচ্ছে না।") }
    }

    @Deprecated("simple voice input")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 1 && res == RESULT_OK) {
            val t = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!t.isNullOrBlank()) { input.setText(t); submit() }
        }
    }

    private fun submit() {
        val cmd = input.text.toString().trim()
        if (cmd.isEmpty()) return
        val url = urlBox.text.toString().trim()
        val token = tokenBox.text.toString().trim()
        if (url.isEmpty()) { log("আগে সার্ভার URL দিন।"); return }
        prefs.edit().putString("url", url).putString("token", token).apply()
        input.setText("")
        log("আপনি: $cmd")
        history.put(JSONObject().put("role", "user").put("text", cmd))
        runAgent(url, token, cmd)
    }

    private fun runAgent(url: String, token: String, cmd: String) = thread {
        try {
            var message = cmd
            for (step in 1..6) {
                val svc = RakibService.instance
                val screen = svc?.readScreen() ?: "(অ্যাক্সেসিবিলিটি সার্ভিস চালু নেই)"
                val res = callServer(url, token, message, screen)
                val reply = res.optString("reply")
                if (reply.isNotBlank()) {
                    log("রাকিব: $reply")
                    tts?.speak(reply, TextToSpeech.QUEUE_ADD, null, null)
                    history.put(JSONObject().put("role", "model").put("text", reply))
                }
                val actions = res.optJSONArray("actions") ?: JSONArray()
                if (actions.length() > 0 && svc == null) {
                    log("⚠ ফোন নিয়ন্ত্রণের জন্য অ্যাক্সেসিবিলিটি সার্ভিস চালু করুন।"); return@thread
                }
                for (i in 0 until actions.length()) {
                    val a = actions.getJSONObject(i)
                    val q = confirmText(a)
                    if (q != null && !svc!!.confirm(q)) { log("রাকিব: ঠিক আছে, কাজটি বাতিল করলাম।"); return@thread }
                    val ok = svc!!.perform(a)
                    if (!ok) log("⚠ অ্যাকশন সফল হয়নি: $a")
                    Thread.sleep(if (a.optString("type") == "open_app") 2000 else 1000)
                }
                if (res.optBoolean("done", true) || actions.length() == 0) break
                message = "(স্বয়ংক্রিয় ধাপ $step - আগের কাজ চালিয়ে যাও)"
                Thread.sleep(1000)
            }
        } catch (e: Exception) {
            log("⚠ ত্রুটি: ${e.message}")
        }
    }

    private fun confirmText(a: JSONObject): String? {
        when (a.optString("type")) {
            "call" -> return "${a.optString("number")} নম্বরে কল করব?"
            "click" -> {
                val t = a.optString("text").lowercase()
                if (sensitive.any { t.contains(it) }) return "\"${a.optString("text")}\" চাপব?"
            }
        }
        return null
    }

    private fun callServer(base: String, token: String, message: String, screen: String): JSONObject {
        val c = URL(base.trimEnd('/') + "/chat").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 30000
        c.readTimeout = 90000 // Render free সার্ভার ঘুম থেকে উঠতে সময় নেয়
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        c.setRequestProperty("X-App-Token", token)
        val body = JSONObject().put("message", message).put("screen", screen).put("history", history)
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        if (code !in 200..299) throw RuntimeException("সার্ভার $code: ${txt.take(200)}")
        return JSONObject(txt)
    }

    private fun log(s: String) = runOnUiThread {
        logView.append(s + "\n\n")
        scroll.post { scroll.fullScroll(android.view.View.FOCUS_DOWN) }
    }

    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}
